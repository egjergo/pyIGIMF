# IGIMF
Based on Yan, Jerabkova, and Kroupa (2021, A&amp;A)
