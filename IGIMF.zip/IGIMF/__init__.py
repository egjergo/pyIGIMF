from .igimf import instance

massfrac, SFR, Mtot, stellar_IMF, ecl_MF, t_IGIMF = instance.main()
